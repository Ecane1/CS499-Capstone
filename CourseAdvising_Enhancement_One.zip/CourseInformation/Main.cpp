


#include <iostream>
#include "CsvRepository.h"
#include "CourseManager.h"
using namespace std;

int main() {

    // Load courses from the CSV file.
    CsvRepository repo("courses.csv");
    CourseManager manager;

    // Load and sort the course list.
    manager.loadFromRepository(repo);
    manager.sortCourses();

    int choice = 0;

    // menu loop.
    while (choice != 3) {
        cout << "1. Print all courses" << endl;
        cout << "2. Print course details" << endl;
        cout << "3. Exit" << endl;
        cout << "Enter choice: ";
        cin >> choice;

        if (choice == 1) {
            manager.printAllCourses();
        }
        else if (choice == 2) {
            string id;
            cout << "Enter course ID: ";
            cin >> id;
            manager.printCourseDetails(id);
        }
        else if (choice != 3) {
            cout << "Invalid choice" << endl;
        }
    }

    return 0;
}

