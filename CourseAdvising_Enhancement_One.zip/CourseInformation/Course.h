#pragma once
#include <string>
#include <vector>
using namespace std;

// Represents a single course in the system.
// This struct holds the course ID, name, and any prerequisite course IDs.


class Course {
public:
    string id;
    string title;
    vector<string> prerequisites;

    Course() = default;

    Course(const string& id, const string& title, const vector<string>& prereqs)
        : id(id), title(title), prerequisites(prereqs) {}
};


