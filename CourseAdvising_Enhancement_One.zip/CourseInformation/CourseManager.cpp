#include "CourseManager.h"
#include <iostream>
#include <algorithm>
using namespace std;

// Loads courses from the provided repository
void CourseManager::loadFromRepository(CourseRepository& repo) {
    courses = repo.loadCourses();
}
// Sorts the vector of courses alphabetically by courseId.
// This replaces the old custom quicksort from the original artifact.
void CourseManager::sortCourses() {
    sort(courses.begin(), courses.end(),
        [](const Course& a, const Course& b) {
            return a.id < b.id;
        });
}
// Prints all courses in the system.
// Assumes courses have already been sorted.
void CourseManager::printAllCourses() const {
    for (const auto& course : courses) {
        cout << course.id << ", " << course.title << endl;
    }
}
// Prints details for a specific course, including prerequisites.
void CourseManager::printCourseDetails(const string& id) const {
    for (const auto& course : courses) {
        if (course.id == id) {
            cout << course.id << ": " << course.title << endl;

            if (course.prerequisites.empty()) {
                cout << "Prerequisites: None" << endl;
            }
            else {
                cout << "Prerequisites: ";
                for (size_t i = 0; i < course.prerequisites.size(); ++i) {
                    cout << course.prerequisites[i];
                    if (i < course.prerequisites.size() - 1)
                        cout << ", ";
                }
                cout << endl;
            }
            return;
        }
    }
    // If no course matches the ID
    cout << "Course not found." << endl;
}

