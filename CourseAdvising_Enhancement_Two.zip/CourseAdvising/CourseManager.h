#pragma once
#include <vector>
#include <string>
#include <unordered_map> 
#include "Course.h"
#include "CourseRepository.h"
using namespace std;

// Manages the list of courses in memory.
// Handles sorting, searching, and printing.



class CourseManager {
private:
    // Stores all loaded courses
     vector<Course> courses; 

     // Hash table for O(1) lookup of courses by their course ID
     unordered_map<string, Course> courseTable;

public:
    // Loads courses from any repository
    void loadFromRepository(CourseRepository& repo);

    // Sorts courses alphabetically by courseId using std::sort.
    void sortCourses();

    // Prints all courses in sorted order.
    void printAllCourses() const;

    // Prints details for a single course.
    void printCourseDetails(const string& id) const;
};


