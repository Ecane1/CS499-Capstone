#pragma once
#include <string>
#include <vector>
using namespace std;

// Represents a single course in the system.
// This struct holds the course ID, name, and any prerequisite course IDs.

// class attributes set to private
class Course {
private:
    string id;
    string title;
    vector<string> prerequisites;

public:

    Course() = default;

    //Getters used to get id, title, prrequisites ensuring class data is using encapsulation
    Course(const string& id, const string& title, const vector<string>& prereqs)
        : id(id), title(title), prerequisites(prereqs) {}

    const string& getId() const { return id; }
    const string& getTitle() const { return title; }
    const vector<string>& getPrerequisites() const { return prerequisites; }


};



