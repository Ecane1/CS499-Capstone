#include "CourseManager.h"
#include <iostream>
#include <algorithm>
using namespace std;

// Loads courses from the repository and builds both the vector
// and the hash table for fast O(1) lookup by course ID.
void CourseManager::loadFromRepository(CourseRepository& repo) {
    // Load all courses into the vector
    courses = repo.loadCourses();

    // Clear the hash table before inserting new data
    courseTable.clear();

    // Insert each course into the hash table using its ID as the key
    for (const auto& c : courses) {
        courseTable[c.getId()] = c;
    }
}

// Sorts the vector of courses alphabetically by course ID.
// This supports Enhancement 1: printing the full course list in order.
void CourseManager::sortCourses() {
    sort(courses.begin(), courses.end(),
        [](const Course& a, const Course& b) {
            return a.getId() < b.getId();
        });
}

// Prints all courses in the system using the sorted vector.
// The vector preserves order, so this produces an alphabetical list.
void CourseManager::printAllCourses() const {
    for (const auto& course : courses) {
        cout << course.getId() << ", " << course.getTitle() << endl;
    }
}

// Prints details for a specific course using the hash table.
// Enhancement 2: O(1) lookup makes this much faster than searching the vector.
void CourseManager::printCourseDetails(const string& id) const {
    // Attempt to find the course in the hash table
    auto it = courseTable.find(id);

    if (it != courseTable.end()) {
        const Course& course = it->second;

        cout << course.getId() << ": " << course.getTitle() << endl;

        // Print prerequisites if they exist
        if (course.getPrerequisites().empty()) {
            cout << "Prerequisites: None" << endl;
        }
        else {
            cout << "Prerequisites: ";
            const auto& prereqs = course.getPrerequisites();

            for (size_t i = 0; i < prereqs.size(); ++i) {
                cout << prereqs[i];
                if (i < prereqs.size() - 1) {
                    cout << ", ";
                }
            }
            cout << endl;
        }
    }
    else {
        cout << "Course not found." << endl;
    }
}

