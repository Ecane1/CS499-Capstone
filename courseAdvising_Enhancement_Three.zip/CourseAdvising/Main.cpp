


#include <iostream>
#include <limits>
#include "CourseManager.h"
#include "CsvRepository.h"
#include "MongoRepository.h"
#include <sstream>


using namespace std;

// menu function
void displayMenu() {
    cout << " Menu:" << endl;
    cout << "  1. Load courses from CSV " << endl;
    cout << "  2. Load courses from MongoDB (simulated)" << endl;
    cout << "  3. Print course list " << endl;
    cout << "  4. Print course details " << endl;
    cout << "  5. Add a course " << endl;
    cout << "  6. Update a course " << endl;
    cout << "  7. Delete a course " << endl;
    cout << "  9. Exit " << endl;
}

int main() {
     // loads course datasets 
    // initialize int variable
    // controls main loop
    CourseManager manager;
    int choice = 0;
    bool running = true;

    // csv file path
    string csvFilename = "courses.csv";

    // while loop 
    // handles user numeric input
    while (running) {
        displayMenu();
        cout << "Enter your choice: ";
        cin >> choice;

        if (cin.fail()) {
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            cout << "Invalid input. Try again." << endl;
            continue;
        }

        switch (choice) {
     // loads courses from csv file
        case 1: {
            CsvRepository csvRepo(csvFilename);
            manager.loadFromRepository(csvRepo);
            cout << "Courses loaded from CSV." << endl;
            break;
        }
     // loads courses from mongDB(simulated) but with correct schema
        case 2: {
            MongoRepository mongoRepo;
            manager.loadFromRepository(mongoRepo);
            cout << "Courses loaded from MongoDB (simulated)." << endl;
            break;
        }
     // sorts and prints courses
        case 3: {
            manager.sortCourses();
            manager.printAllCourses();
            break;
        }
     // prints course prerequisites
        case 4: {
            cout << "Enter course ID: ";
            string id;
            cin >> id;
            manager.printCourseDetails(id);
            break;
        }
     // adds a new course from user input
        case 5: {
            string id, title;
            cout << "Enter new course ID: ";
            cin >> id;

            cout << "Enter course title: ";
            cin.ignore();
            getline(cin, title);

            vector<string> prereqs;
            cout << "Enter prerequisites separated by spaces (or NONE): ";
            string input;
            getline(cin, input);

            if (input != "NONE") {
                stringstream ss(input);
                string token;
                while (ss >> token) prereqs.push_back(token);
            }

            Course newCourse(id, title, prereqs);
            manager.addCourse(newCourse);
            cout << "Course added." << endl;
            break;
        }
     // updates a course from user input
        case 6: {
            string id, title;
            cout << "Enter course ID to update: ";
            cin >> id;

            cout << "Enter new title: ";
            cin.ignore();
            getline(cin, title);

            vector<string> prereqs;
            cout << "Enter new prerequisites separated by spaces (or NONE): ";
            string input;
            getline(cin, input);

            if (input != "NONE") {
                stringstream ss(input);
                string token;
                while (ss >> token) prereqs.push_back(token);
            }

            Course updated(id, title, prereqs);
            manager.updateCourse(updated);
            cout << "Course updated." << endl;
            break;
        }
     // deletes a course from user input
        case 7: {
            string id;
            cout << "Enter course ID to delete: ";
            cin >> id;

            manager.removeCourse(id);
            cout << "Course deleted." << endl;
            break;
        }
     // exits program
        case 9:
            cout << "Exiting program." << endl;
            running = false;
            break;

        default:
            cout << "Invalid choice. Try again." << endl;
            break;
        }
    }

    return 0;
}

