#include "MongoRepository.h"
#include <algorithm>

using namespace std;

// Loads hardcoded sample courses into the repository
vector<Course> MongoRepository::loadCourses() {
    courses.clear();

    courses.emplace_back("CS101", "Introduction to Computer Science", vector<string>{});
    courses.emplace_back("CS200", "Data Structures", vector<string>{"CS101"});
    courses.emplace_back("CS300", "Advanced Algorithms", vector<string>{"CS200"});
    courses.emplace_back("CS305", "Database Systems", vector<string>{"CS200"});
    courses.emplace_back("CS310", "Software Engineering", vector<string>{"CS200"});

    return courses;
}
    // function to add a new course
void MongoRepository::createCourse(const Course& course) {
    courses.push_back(course);
}
   // fuction to read a course
Course MongoRepository::readCourse(const string& id) {
    for (auto& c : courses) {
        if (c.getId() == id) {
            return c;
        }
    }
    return Course(); // empty course if not found
}
   // function to update an existing course
void MongoRepository::updateCourse(const Course& course) {
    for (auto& c : courses) {
        if (c.getId() == course.getId()) {
            c = course;
            return;
        }
    }
}
    // function to delete a coure
void MongoRepository::deleteCourse(const string& id) {
    courses.erase(
        remove_if(courses.begin(), courses.end(),
            [&](const Course& c) { return c.getId() == id; }),
        courses.end()
    );
}



