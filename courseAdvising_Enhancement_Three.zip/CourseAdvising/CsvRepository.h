#pragma once
#include "CourseRepository.h"
#include <string>
using namespace std;

// Implementation of CourseRepository that loads courses from a CSV file.
class CsvRepository : public CourseRepository {
private:
    string filename;  // Path to the CSV file


    // Constructor accepts the CSV filename.
    // Loads courses from the CSV and returns them as a vector.
public:
    explicit CsvRepository(const string& file);
    vector<Course> loadCourses() override;

    void createCourse(const Course& course) = 0;
    Course readCourse(const string& id) = 0;
    void updateCourse(const Course& course) = 0;
    void deleteCourse(const string& id) = 0;


};



