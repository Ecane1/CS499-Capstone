#include "CsvRepository.h"
#include <fstream>
#include <sstream>
#include <iostream>


using namespace std;


CsvRepository::CsvRepository(const string& file)
    : filename(file) {}



    // Reads the CSV file line-by-line and converts each row into a Course object.
vector<Course> CsvRepository::loadCourses() {
    vector<Course> courses;
    ifstream fileStream(filename);

    // If the file cannot be opened, return an empty list.
    if (!fileStream.is_open()) {
        cout << "Error: Could not open file " << filename << endl;
        return courses;
    }

    string line;
    bool firstLine = true;

    while (getline(fileStream, line)) {

        // Used to detect and remove UTF 8 BOM
        if (firstLine && !line.empty() && (unsigned char)line[0] == 0xEF) {
            line = line.substr(3);
        }
        firstLine = false;

        // Skip empty lines to avoid creating empty Course objects.
        if (line.empty()) continue;

        stringstream ss(line);
        string id, title, prereqField;

        // Extract course ID, course title, and prerequisite (comma-separated)
        getline(ss, id, ',');
        getline(ss, title, ',');
        getline(ss, prereqField);

        // Skip malformed rows missing ID or title
        if (id.empty() || title.empty()) continue;

        // Parse prerequisites if the field is not empty
        vector<string> prereqs;
        if (!prereqField.empty()) {
            stringstream ps(prereqField);
            string token;

            // Split prereqField by spaces
            while (getline(ps, token, ' ')) {
                if (!token.empty()) prereqs.push_back(token);
            }
        }
        // Create a Course object and add it to the list
        courses.emplace_back(id, title, prereqs);
    }
    // Return the fully loaded course list
    return courses;
}

