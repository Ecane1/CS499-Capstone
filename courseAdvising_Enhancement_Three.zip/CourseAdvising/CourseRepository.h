

#pragma once
#include <vector>
#include "Course.h"
using namespace std;

// Abstract interface for loading courses.
// Enhancement 1 uses CSV, but Enhancement 3 will use MongoDB.
// This interface allows swapping data sources without changing CourseManager.


 // Must return a list of Course objects loaded from some data source.
 // Virtual destructor ensures proper cleanup when using polymorphism.

class CourseRepository {
public:

    virtual ~CourseRepository() = default;
    virtual vector<Course> loadCourses() = 0;


    // CRUD operations
    virtual void createCourse(const Course& course) = 0;
    virtual Course readCourse(const string& id) = 0;
    virtual void updateCourse(const Course& course) = 0;
    virtual void deleteCourse(const string& id) = 0;

};



