﻿

#pragma once
#include "CourseRepository.h"
#include <vector>
#include <string> 
using namespace std;

// This class simulates a MongoDB-backed repository for courses. It implements
// the CourseRepository interface so it can be used interchangeably with other
// data sources (like CsvRepository).
//
// In Enhancement 3, this acts as a stand‑in for a real MongoDB connection.
// Instead of querying a database, it stores a vector<Course> in memory.



class MongoRepository : public CourseRepository {
private:
    vector<Course> courses;   

public:

    // Default constructor
    MongoRepository() = default;

    //Returns a list of hardcoded or simulated MongoDB course data.
    // This allows CourseManager to load data without caring about the source.
    vector<Course> loadCourses() override;

    // CRUD operations (simulated)
    // These modify the in‑memory vector<Course> to mimic database behavior.
    void createCourse(const Course& course) override;
    Course readCourse(const string& id) override;
    void updateCourse(const Course& course) override;
    void deleteCourse(const string& id) override;


    

};


