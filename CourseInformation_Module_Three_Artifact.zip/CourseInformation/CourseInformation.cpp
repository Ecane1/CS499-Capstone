


// Name        : CourseInformation.cpp
// Author      : Eliott Cane
// Version     : 1.0
// Copyright   : Copyright � 2023 SNHU COCE
// Description : Sorting course information





#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <sstream>
#include <algorithm>



using namespace std;

//struct to hold course information
struct Course {
    string courseId;
    string courseTitle;
    string prerequisite;


};

//displays courseId and courseTitle seperated by a comma
void displayCourse(const Course& course) {
    cout << course.courseId << "," << course.courseTitle << endl;




}
//displays courseId,courseTitle and any prerequisites that are needed for that course
void displayCoursePrereq(const Course& course) {
    cout << course.courseId << ", " << course.courseTitle << endl;
    cout << "Prerequisite: " << course.prerequisite << endl;

}


//method to load courses into data structure
//vector to hold course
vector<Course> loadCourses(const string& filename) {
    vector<Course> courses;

    ifstream file(filename);
    if (!file.is_open()) {
        cout << "Error: Could not open file " << filename << endl;

    }
    else {
        cout << "file is opened" << endl;
    }
    //reads each line and stores in line variable
    string line;
    bool firstLine = true;
    while (getline(file, line)) {
        if (firstLine && !line.empty() && static_cast<unsigned char>(line[0]) == 0xEF) {
            line = line.substr(3);
        }
        firstLine = false;




        stringstream ss(line);
        Course course;
        string courseId;
        string title;
        string prerequisite;

        //seperates and stores courseId,courseTitle,prerequisite in that order and stops at the comma for each
        getline(ss, course.courseId, ',');
        getline(ss, course.courseTitle, ',');
        getline(ss, course.prerequisite);


        //displays no data if courseId or courseTitle are empty
        if (course.courseId.empty() || course.courseTitle.empty()) {
            cout << "no data" << endl;
            continue;
        }
        //stores that course in courses vector
        courses.push_back(course);
    }
    //returns courses
    return courses;
}


//method to print courses 
void printCourses(const vector<Course>& courses) {

    for (const auto& course : courses) {
        displayCourse(course);
    }
    cout << endl;
}

//method to search for a course
void searchCourse(const vector<Course> courses) {
    string courseId;
    cout << "what course do you want to know about ? ";
    cin >> courseId;

    for (const auto& course : courses) {
        if (course.courseId == courseId) {
            displayCoursePrereq(course);

            return;
        }
    }

    cout << "CourseId " << courseId << " not found." << endl;
}



// partition method that splits Course vector in two, high and low  
int partition(vector<Course>& courses, int begin, int end) {


    //set low and high equal to begin and end
    int low = begin;
    int high = end;

    bool done = false;
    // Set Pivot as middlePoint element to compare (string)  
    int pivot = low + (high - low) / 2;

    // while not done
    while (!done) {
        // keep incrementing low index while courses[low].courseId < Pivot
        while (courses[low].courseId < (courses[pivot].courseId)) {
            low += 1;
        }
        // keep decrementing high index while Pivot < courses[high].courseId
        while (courses[pivot].courseId.compare(courses[high].courseId) < 0) {
            high -= 1;
        }
        /* If there are zero or one elements remaining,
           all bids are partitioned. Return high */
        if (low >= high) {
            done = true;
        }
        // else swap the low and high bids (built in vector method)
           // move low and high closer ++low, --high

        else {
            swap(courses[low], courses[high]);
            low += 1;
            high -= 1;
        }
    }

    //return high
    return high;
}




void quickSort(vector<Course>& courses, int begin, int end) {


    //set mid equal to 0
    int mid = 0;

    /* Base case: If there are 1 or zero bids to sort,
    partition is already sorted otherwise if begin is greater
    than or equal to end then return*/
    if (begin >= end) {
        return;
    }

    /* Partition courses into low and high such that
    midpoint is location of last element in low */
    mid = partition(courses, begin, end);

    // recursively sort low partition (begin to mid)
    quickSort(courses, begin, mid);

    // recursively sort high partition (mid+1 to end)
    quickSort(courses, mid + 1, end);
}


//  Menu for user interface
void displayMenu() {
    cout << "Menu:" << endl;
    cout << "  1. Load data structure" << endl;
    cout << "  2. print course list" << endl;
    cout << "  3. print course" << endl;
    cout << "  9. Exit" << endl;



}
// Main method
// vector to hold courses
// cvs file stores as variable filename
int main() {
    vector<Course> csCourses;
    int choice;
    string filename = "E:\\courseInformation\\CS 300 ABCU_Advising_Program_Input.csv";
    csCourses = loadCourses(filename);

    //while loop that loops through menu options

    while (true) {
        displayMenu();

        cout << "Enter your choice: ";
        cin >> choice;



        switch (choice) {
            // loads courses and outputs size
        case 1:  cout << csCourses.size() << " courses loaded" << endl;




            break;
            // quicksort sorts csCourses loaded and displays sorted csCourses
        case 2: quickSort(csCourses, 0, csCourses.size() - 1);
            printCourses(csCourses);
            break;
            //searchCourse outputs courses and prerequisites
        case 3: searchCourse(csCourses);
            break;
        case 9:
            //exit the program
            cout << "Exiting program." << endl;
            return 0;


        default:
            //if invalid choice, message to try again
            cout << "Invalid choice. Try again." << endl;
            break;
        }
    }
    return 0;





}
